
import os

import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def anallyze_by_type(path):
    FILES = []
    for root, dirs, files in os.walk(path):
        for file in files:
            FILES.append(file.split(b'.')[-1])
    FILES.sort()
    result = []
    for item in set(FILES):
        result.append(f'There are {FILES.count(item)} files of type: {str(item)}')
    return '\n'.join(result)


