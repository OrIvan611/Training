import os
import logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)
path = "C:/Users/LENOVO/Desktop/or_ivan"

SIZE_LIST = []

def find_size_in_dir(dir):
    list_of_files = filter(lambda x: os.path.isfile(os.path.join(dir, x)),
                           os.listdir(dir))
    files_with_size = [(file_name, os.stat(os.path.join(dir, file_name)).st_size)
                       for file_name in list_of_files]

    for file_name, size in files_with_size:
        SIZE_LIST.append((file_name, size))


def find_size(dir_name):
    for root, dirs, files in os.walk(dir_name):
        for dir in dirs:
            find_size_in_dir(root + b'/' + dir)
    SIZE_LIST.sort(key=lambda x:x[-1], reverse=True)
    result = []
    for item in SIZE_LIST[-10:]:
        result.append(f'File name: {item[0]}, File size: {item[1]}')
    return '\n'.join(result)


# find_size()