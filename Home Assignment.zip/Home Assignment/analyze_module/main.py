import logging
# import messageBroker
import sys, os, pika
from anallyze_by_size import *
from anallyze_by_type import *

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='size')
    channel.queue_declare(queue='type')

    def callback_anallyze_by_size(ch, method, properties, body):
        result = find_size(body)
        ch.basic_publish(exchange='', routing_key=properties.reply_to,
                         properties=pika.BasicProperties(correlation_id=properties.correlation_id),
                         body=str(result))

    def callback_anallyze_by_type(ch, method, properties, body):
        result = anallyze_by_type(body)
        ch.basic_publish(exchange='', routing_key=properties.reply_to,
                         properties=pika.BasicProperties(correlation_id=properties.correlation_id),
                         body=str(result))

    channel.basic_consume(queue='size', on_message_callback=callback_anallyze_by_size, auto_ack=True)
    channel.basic_consume(queue='type', on_message_callback=callback_anallyze_by_type, auto_ack=True)

    logger.info("Analyze module is listening...")

    channel.start_consuming()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
