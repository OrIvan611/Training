import os.path
import os


PASSWORD_START = 'password: '

def is_password_in_file(file):
    if file.endswith(b'.txt'):
        with open(file) as f:
            text = f.read()
            if PASSWORD_START in text:
                after_password = text.split(PASSWORD_START)[-1]
                return f"The password is: {after_password.split()[0]}"


FILES = []
path = "directory"
def find_password(path):
    result = []
    for root, dirs, files in os.walk(path):
        for file in files:
            password = is_password_in_file(root + b'/' + file)
            if password:
                result.append(password)
    return '\n'.join(result)

# find_password(path)