import logging
# import messageBroker
import sys, os, pika
from find_password import *

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def main():
    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()

    channel.queue_declare(queue='password')

    def callback_password(ch, method, properties, body):
        result = find_password(body)
        ch.basic_publish(exchange='', routing_key=properties.reply_to,
                         properties=pika.BasicProperties(correlation_id=properties.correlation_id),
                         body=str(result))

    channel.basic_consume(queue='password', on_message_callback=callback_password, auto_ack=True)
    logger.info("Password module is listening...")


    channel.start_consuming()


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        try:
            sys.exit(0)
        except SystemExit:
            os._exit(0)
