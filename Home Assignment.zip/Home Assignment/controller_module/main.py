import logging
# import messageBroker
import pika
import uuid
import json


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


def write_to_json(file_name, content):
    content = content.decode('UTF-8')
    lines = content.split('\n')
    with open(file_name, 'w') as f:
        json.dump(lines, f)

def size_callback(ch, method, props, body):
    write_to_json('size_result.json', body)

def type_callback(ch, method, props, body):
    write_to_json('type_result.json', body)

def password_callback(ch, method, props, body):
    write_to_json('password_result.json', body)

if __name__ == '__main__':
    logger.info("Controller module is running and listening...")

    connection = pika.BlockingConnection(pika.ConnectionParameters(host='localhost'))
    channel = connection.channel()


    channel.queue_declare(queue='size')
    channel.queue_declare(queue='type')
    channel.queue_declare(queue='password')

    size_result = channel.queue_declare(queue='size_results')
    size_callback_queue = size_result.method.queue
    type_result = channel.queue_declare(queue='type_results')
    type_callback_queue = type_result.method.queue
    password_result = channel.queue_declare(queue='password_results')
    password_callback_queue = password_result.method.queue

    channel.basic_publish(exchange='', routing_key='size', body=b'../directory',
                          properties=pika.BasicProperties(reply_to=size_callback_queue, correlation_id=str(uuid.uuid4())))

    channel.basic_publish(exchange='', routing_key='type', body=b'../directory',
                          properties=pika.BasicProperties(reply_to=type_callback_queue, correlation_id=str(uuid.uuid4())))

    channel.basic_publish(exchange='', routing_key='password', body=b'../directory',
                          properties=pika.BasicProperties(reply_to=password_callback_queue, correlation_id=str(uuid.uuid4())))


    channel.basic_consume(queue=size_callback_queue, on_message_callback=size_callback, auto_ack=True)
    channel.basic_consume(queue=type_callback_queue, on_message_callback=type_callback, auto_ack=True)
    channel.basic_consume(queue=password_callback_queue, on_message_callback=password_callback, auto_ack=True)
    channel.start_consuming()
